<template>
    <body>
    

<!--header-->
<div id="contenedor-ppal">
 <nav class="navbar navbar-dark fixed-top bg-lighter flex-md-nowrap p-0 shadow">
  <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="#"><span class="light-logo">
	 <img src="../assets/logo-inter-lifebank.png" alt="logo"  class="img-fluid"></span></a>


<div class="dropdown float-lg-right mr-5">
  <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
   Mi cuenta
  </button>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
 
<ul class="list-group list-group-flush">
  <li class="list-group-item"><i class="fas fa-user"></i> Mi Perfil</li>
  <li class="list-group-item"><i class="fas fa-envelope"></i> Mensaje</li>
  <li class="list-group-item"><i class="fas fa-cog"></i>Configuración</li>
  <li class="list-group-item" ><i class="fas fa-sign-out-alt"></i> <router-link  to="/login" v-on:click.native="logout()" replace>Salir</router-link></li>
 
</ul>   
  </div>
</div>
 </nav>
<!--fin header-->

<!--Sidebar-->

    <div class="container-fluid">
  <div class="row">
    <nav class="col-md-2 d-none d-md-block bg-light sidebar">
      <div class="sidebar-sticky">
        <ul class="nav flex-column mt-3">
          <li class="nav-item" style="background-color:white;">
            <a class="nav-link active" href="#">
           <i class="fas fa-home"></i>
              Principal<span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">
              <i class="fas fa-piggy-bank"></i>
           <router-link  to="/detalle"  replace>Productos bancarios</router-link>
            </a>
          </li>
          </ul>
          <hr>
             <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 item-celeste">
          <span>TRANFERENCIAS</span>
          <a class="d-flex align-items-center text-muted" href="#">
            <i class="fas fa-exchange-alt item-celeste"></i>
          </a>
        </h6>
         <hr>
         <ul class="nav flex-column mt-3">
      <li class="nav-item">
            <a class="nav-link" href="#">
              <i class="fas fa-exchange-alt"></i>
             Transferencias entre Cuentas
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">
            <i class="fas fa-exchange-alt"></i>
             Transferencia a terceros
            </a>
          </li>
       </ul>
<hr>
            <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 item-celeste">
          <span>PAGOS</span>
          <a class="d-flex align-items-center text-muted" href="#">
          <i class="fas fa-money-bill-wave item-celeste"></i>
          </a>
        </h6>
        <hr>
 <ul class="nav flex-column mt-3">
 <li class="nav-item">
            <a class="nav-link" href="#">
             <i class="far fa-credit-card"></i>
             Pago tarjeta de crédito propia
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">
            <i class="far fa-credit-card"></i>
             Pago tarjeta de crédito a terceros
            </a>
          </li>
          
            <li class="nav-item">
            <a class="nav-link" href="#">
             <i class="fas fa-money-bill-wave"></i>
            Pago de préstamo bancario
            </a>
          </li>
          
            <li class="nav-item">
            <a class="nav-link" href="#">
             <i class="fas fa-money-bill-wave"></i>            
             Pago de préstamo bancario a terceros
            </a>
          </li>
</ul>

       

<hr>

    <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 item-celeste">
          <span>FIDELIZACIÓN</span>
          <a class="d-flex align-items-center text-muted" href="#">
           <i class="fas fa-user-tie item-celeste"></i>
          </a>
        </h6>
        
        <hr>
<ul class="nav flex-column mt-3">
                 <li class="nav-item">
            <a class="nav-link" href="#">
             <i class="fas fa-users-cog"></i>
             Administrar beneficiarios
            </a>
          </li>

        </ul>

  </div>
</nav>


</div>

</div>
    
<!--main-->

<main role="main" class="col-md-12 ml-sm-auto col-lg-10 px-4" >
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom mt-5">
        <h4 class="h4 text-muted">Pagina Principal - <span class="badge badge-secondary">herbert palacios - CU:0362686466</span></h4>
        <div class="btn-toolbar mb-2 mb-md-0">
          <div class="btn-group mr-2">
            <button type="button" class="btn btn-sm btn-outline-secondary">Proteja sus Operaciones</button>
            <button type="button" class="btn btn-sm btn-outline-secondary">Contactenos</button>
          </div>
         
        </div>
      </div>



<!-- caontenido inter-->
<div class="container mt-4">
  <div class="row">
    <div class="col-md-3">
      <!-- Content -->
      <div class="card text-white bg-info mb-3" style="max-width: 18rem;">
  <div class="card-header"><i class="far fa-bell"></i> Notificaciones</div>
  <div class="card-body">
    <h5 class="card-title"> 6 Mensajes</h5>
    
     </div>
</div>
    </div>
    <div class="col-md-3">
      <!-- Content -->
      <div class="card text-white bg-primary mb-3" style="max-width: 18rem;">
  <div class="card-header"><i class="fas fa-hand-holding-usd"></i> Balance Mesnsual</div>
  <div class="card-body">
    <h5 class="card-title"> $1,259</h5>
     </div>
</div>
    </div>
    <div class="col-md-3">
      <!-- Content -->
      <div class="card text-white bg-warning mb-3" style="max-width: 18rem;">
  <div class="card-header"><i class="fas fa-dollar-sign"></i> Saldo actual</div>
  <div class="card-body">
    <h5 class="card-title"> $589.00</h5>
     </div>
</div>
    </div>
    
     <div class="col-md-3">
      <!-- Content -->
      <div class="card text-black-50 bg-light  mb-3" style="max-width: 18rem;">
  <div class="card-header"><i class="fas fa-file-invoice-dollar"></i> Prestamo actual</div>
  <div class="card-body">
    <h5 class="card-title"> $5,789.00</h5>
     </div>
</div>
    </div>

  </div>
</div>

<hr>
<div class="album py-5">
    <div class="container">

      <div class="row">
        
        <div class="card mb-3 mr-4" style="max-width: 520px;">
  <div class="row">
    <div class="col-md-4">
      <img alt="" height="210" src="images/ico-products01.jpg" width="155" class="img-fluid" />
    </div>
    <div class="col-md-8">
      <div class="card-body">
        <h5 class="card-title text-primary">Ahorror y Cumplir mis objetivo</h5>
        <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
        <p class="card-text"><small class="text-muted">Ultima actualización 3 mins</small></p>
             </div>
    </div>
  </div>
</div>


        <div class="card mb-3" style="max-width: 520px;">
  <div class="row">
    <div class="col-md-4">
        <img alt="" height="210" src="images/ico-products02.jpg" width="155" class="img-fluid" />
    </div>
    <div class="col-md-8">
      <div class="card-body">
        <h5 class="card-title text-primary">Credito Pre Aprobado</h5>
        <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
        <p class="card-text"><small class="text-muted">Ultima actualización  2 días </small></p>
       
      </div>
    </div>
  </div>
</div>


  
      </div>
      
      
    </div>
    
    
    
    
    
    
    <div class="container">

      <div class="row">
        
        <div class="card mb-3 mr-4" style="max-width: 520px;">
  <div class="row">
    <div class="col-md-4">
      <img alt="" height="210" src="images/ico-products03.jpg" width="155" class="img-fluid" />
    </div>
    <div class="col-md-8">
      <div class="card-body">
        <h5 class="card-title text-primary">Tarjetas de Credito</h5>
        <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
        <p class="card-text"><small class="text-muted">Ultima actualización 3 mins</small></p>
             </div>
    </div>
  </div>
</div>


        <div class="card mb-3" style="max-width: 520px;">
  <div class="row">
    <div class="col-md-4">
        <img alt="" height="210" src="images/ico-products04.jpg" width="155" class="img-fluid" />
    </div>
    <div class="col-md-8">
      <div class="card-body">
        <h5 class="card-title text-primary">Vivir Tramquilo</h5>
        <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
        <p class="card-text"><small class="text-muted">Ultima actualización  2 días </small></p>
       
      </div>
    </div>
  </div>
</div>

<div class="container">

      <div class="row">
        
        <div class="card mb-3 mr-4" style="max-width: 520px;">
  <div class="row">
    <div class="col-md-4">
      <img alt="" height="210" src="images/ico-products05.jpg" width="155" class="img-fluid" />
    </div>
    <div class="col-md-8">
      <div class="card-body">
        <h5 class="card-title text-primary">Recargar Movil</h5>
        <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
        <p class="card-text"><small class="text-muted">Ultima actualización 3 mins</small></p>
             </div>
    </div>
  </div>
</div>


        <div class="card mb-3" style="max-width: 520px;">
  <div class="row">
    <div class="col-md-4">
        <img alt="" height="210" src="images/ico-products06.jpg" width="155" class="img-fluid" />
    </div>
    <div class="col-md-8">
      <div class="card-body">
        <h5 class="card-title text-primary">Mis Recibos</h5>
        <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
        <p class="card-text"><small class="text-muted">Ultima actualización  2 días </small></p>
       
      </div>
    </div>
  </div>
</div>


  
      </div>
      
      
    </div>
  
      </div>
      
      
    </div>
    
    
    
    
    
    
    
    
    
    
    
    
  </div>

  


  
  </main>
</div>

    </body>
</template>

<script>
export default {
    name:'detalle',
    data() {
        return {};
    }
}
</script>

<style scoped>
     body {
  font-size: .875rem;
  background-color: #ffffff !important;
  background-image: none;
 
}



  .bd-placeholder-img {
       font-size: 1.125rem;
       text-anchor: middle;
       -webkit-user-select: none;
       -moz-user-select: none;
       -ms-user-select: none;
       user-select: none;
     }

     @media (min-width: 768px) {
       .bd-placeholder-img-lg {
         font-size: 3.5rem;
       }
     }

 

.feather {
  width: 16px;
  height: 16px;
  vertical-align: text-bottom;
}

/*
 * Sidebar
 */

.sidebar {
  position: fixed;
  top: 0;
  bottom: 0;
  left: 0;
  z-index: 100; 
  padding: 48px 0 0; 
  box-shadow: inset -1px 0 0 rgba(0, 0, 0, .1);
}

.sidebar-sticky {
	background-position: bottom;
	position: relative;
	top: 0;
	height: calc(100vh - 48px);
	padding-top: .5rem;
	overflow-x: hidden;
	overflow-y: auto;
	background-color: #9ff0fc;
	background-image: url('../assets/sidebar-gb-ext.jpg');
	background-size:cover;
	
	
}

@supports ((position: -webkit-sticky) or (position: sticky)) {
  .sidebar-sticky {
    position: -webkit-sticky;
    position: sticky;
  }
}

.sidebar .nav-link {
	font-weight: 500;
	color: #0a1c48;
}

.sidebar .nav-link .feather {
  margin-right: 4px;
  color: #999;
}

.sidebar .nav-link.active {
  color: #007bff;
}

.sidebar .nav-link:hover .feather,
.sidebar .nav-link.active .feather {
  color: inherit;
}

.sidebar .nav-link:hover {
	color: #007bff;
	background-color: #FFFFFF;
}


.sidebar-heading {
  font-size: .75rem;
  text-transform: uppercase;
}

.bg-lighter {
	background: #f2f2f2;
}

/*
 * Contenido
 */

[role=main] {
  padding-top: 133px; 
}

@media (min-width: 768px) {
  [role=main] {
    padding-top: 48px;
  }
}

/*
 * Nav
 */

.navbar-brand {
  padding-top: .75rem;
  padding-bottom: .75rem;
  font-size: 1rem;
  background-color: #9ff0fc;
 
}

.navbar .form-control {
  padding: .75rem 1rem;
  border-width: 0;
  border-radius: 0;
}

.form-control-dark {
  color: #fff;
  background-color: rgba(255, 255, 255, .1);
  border-color: rgba(255, 255, 255, .1);
}

.form-control-dark:focus {
  border-color: transparent;
  box-shadow: 0 0 0 3px rgba(255, 255, 255, .25);
  
}
.item-celeste {
color:#007bff;
}



</style>