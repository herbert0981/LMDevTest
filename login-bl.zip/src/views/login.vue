<template>
    <div id="login">
        <!-- box registro--><form class="form-signin">
  <img class="mb-4 ml-5 img-fluid" src="../assets/logo-login-lifebank.png"  alt="">
  <h1 class="h6 mt-3 font-weight-normal text-center text-muted">Por favor registrese</h1>
  <label for="inputEmail" class="sr-only">Email </label>
  <input type="text" id="inputEmail" class="form-control"  v-model="input.username"  placeholder="Nombre de Usuario" required autofocus >
  <label for="inputPassword" class="sr-only">Password</label>
  <input type="password" id="inputPassword"  v-model="input.password"   class="form-control" placeholder="Password" required >
  <div class="checkbox mb-3">
    <label>
      <input type="checkbox" value="remember-me"> Recordar contrase&ntilde;a
    </label>
  </div>
  <button class="btn btn-lg btn-primary btn-block"  v-on:click="login()"  type="submit"  >Ingresar</button>
  <p class="mt-5 mb-3 text-muted text-center">&copy; 2019</p>
</form>

        
    </div>
</template>


<script>
    export default {
        name: 'Login',
        data() {
            return {
                input: {
                    username: "",
                    password: ""
                }
            }
        },
        methods: {
            login() {
                if(this.input.username != "" && this.input.password != "") {
                    if(this.input.username == this.$parent.mockAccount.username && this.input.password == this.$parent.mockAccount.password) {
                        this.$emit("authenticated", true);
                        this.$router.replace({ name: "secure" });
                        
                    } else {
                        console.log("El Usuario o Password es incorrecto");
                    }
                } else {
                    console.log("Un nombre de usuario y contraseña deben estar presentes");
                }
            }
        }
    }
</script>

<style>
  .bd-placeholder-img {
       font-size: 1.125rem;
       text-anchor: middle;
       -webkit-user-select: none;
       -moz-user-select: none;
       -ms-user-select: none;
       user-select: none;
     }

     @media (min-width: 768px) {
       .bd-placeholder-img-lg {
         font-size: 3.5rem;
       }
     }

     html,
     body {
       height: 100%;
     }

     body {
	display: -ms-flexbox;
	background-position: center top;
	display: flex;
	-ms-flex-align: center;
	align-items: center;
	padding-top: 40px;
	padding-bottom: 40px;
	background-color: #B6F6FF;
	background-image: url('../assets/bg-ppa-login.jpg');
	background-size:cover;
}

     .form-signin {
       width: 100%;
       max-width: 330px;
       padding: 15px;
       margin: auto;
     }
     .form-signin .checkbox {
       font-weight: 400;
     }
     .form-signin .form-control {
       position: relative;
       box-sizing: border-box;
       height: auto;
       padding: 10px;
       font-size: 16px;
     }
     .form-signin .form-control:focus {
       z-index: 2;
     }
     .form-signin input[type=email] {
       margin-bottom: -1px;
       border-bottom-right-radius: 0;
       border-bottom-left-radius: 0;
     }
     .form-signin input[type=password] {
       margin-bottom: 10px;
       border-top-left-radius: 0;
       border-top-right-radius: 0;
     }
</style>